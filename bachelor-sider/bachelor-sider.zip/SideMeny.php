<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title></title>
    </head>
    <body>
        <div class="sideMeny">
            <a href="" class="blaaLink">Undermeny 1</a><br/>
            <a href="" class="blaaLink">Undermeny 1</a><br/>
            <a href="" class="blaaLink">Undermeny 1</a>
        </div>
        <?php

        ?>
    </body>
</html>


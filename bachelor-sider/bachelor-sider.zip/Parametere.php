<?php
$studieaar=" 2017/2018";
$statusrapport=" 20.10.2017";
$prosjektskisse = " 1.12.2017";
$forprosjekt=" 19.1.2018";
$innlevering =" 23.5.2018";
$presentasjonsdager = "11.6 - 14.6.2018";
?>

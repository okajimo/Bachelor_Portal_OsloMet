<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title></title>
    </head>
    <body>
        <div class="topMenu">
            <a id="logolink" href="index.php" >
                <img id="logo"alt="Home" src="Hioa-logo.png" width="250px" height="100px">
            </a>
            <div class="menyTekst">Bachelorprosjekt i informasjonsteknologi</div>
            <div class="meny">
                <div class="link">
                    <a href="Informasjon.php" class="whiteLink" >Informasjon</a>
                </div>
            </div>
            <div class="meny">
                <div class="link">
                    <a href="Prosjektforslag.php" class="whiteLink" >Prosjektforslag</a>
                </div>
            </div>
            <div class="meny">
                <div class="link">
                    <a href="TidligereProsjekter.php" class="whiteLink" >Tidligere prosjekter</a>
                </div>
            </div>
            <div class="meny">
                <div class="link">
                    <a href="https://www.cs.hioa.no/data/bachelorprosjekt/reg/" class="whiteLink" >Grupper</a>
                </div>
            </div>
            <div class="meny">
                <div class="link">
                    <a href="Kontakt.php" class="whiteLink" >Kontakt</a>
            </div>
            </div>
        </div>
        <br/>
        <?php

        ?>
    </body>
</html>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>Bachelorprosjekt</title>
    </head>
    <body>
    <?php
        // Added by Amir to convert to UTF-8, needed in addition to meta tag in html     
        header('Content-type: text/html; charset=utf-8');
        //END Amir        
        include "toppMeny.php";
        include "Parametere.php";
    ?>
        <div class="tekstUtenMenyUtenBilde">
                <h2>Ta kontakt med oss!</h2>
                Her er våre adresser: 
                <br/><br/>
                <h3>Besøksadresse</h3>    
                Pilestredet 35 - inngang fra Holbergs plass - rett ovenfor trikkeholdeplassen Holbergs plass 
                <h3>Brev</h3> 
                Høgskolen i Oslo og Akershus <br/>
                Fakultet for Teknlologi, Kunst og Design <br/>
                Institutt for Informasjonsteknologi <br/>
                Postboks 4, St. Olavs plass, 0130 Oslo 
                <h3>Telefon</h3> 
                22 45 32 00 (sentralbord) 
                <h3>E-post</h3> 
                Prosjektkontakt: Tor Krattebøl : tor.krattebol(a)hioa.no
        </div>
    </body>
</html>





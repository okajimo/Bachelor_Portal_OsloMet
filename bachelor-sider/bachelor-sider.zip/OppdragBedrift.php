<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title>Bachelorprosjekt</title>
    </head>
    <body>
    <?php
    	header('Content-type: text/html; charset=utf-8');
        include "toppMeny.php";
        include "Parametere.php";
    ?>
        <div class="sideMenyUtenBilde">
            <a href="OppdragsgivereIntro.php" class="blaaLink">Introduksjon</a><br/>
            <a href="OppdragProsjekt.php" class="blaaLink">Hva er et bachelorprosjekt?</a><br/>
            <a href="OppdragStudent.php" class="blaaLink">Hva kan en datastudent?</a><br/>
            <a href="OppdragSammarbeid.php" class="blaaLink">Samarbeid med bedrifter</a><br/>
            <a href="OppdragBedrift.php" class="blaaLink">Har din bedrift et prosjekt?</a><br/>
            <a href="OppdragKontakt.php" class="blaaLink">Ta kontakt</a><br/>
        </div>
        <div class="tekstMedMenyUtenBilde">
                <h2>En samarbeidsavtale</h2>
                <h3>Avtale</h3>
                Oppdragsgiver og Høgskolen i Oslo og Akershus inngår en formell avtale om prosjektet.
                Den beskriver partenes plikter og rettigheter. Vi har laget en standardavtale (og en engelsk versjon),
                men det er fullt mulig å lage en tilleggsavtale hvis det ønskes andre formuleringer.
                Prosjektavtalen inngås normalt i desember/januar. 
<br/><br/><br/><br/><br/><br/><br/>
          </div>
    </body>
</html>




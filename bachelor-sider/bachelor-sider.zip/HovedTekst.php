<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="style.css" />
        <title></title>
    </head>
    <body>
    <div class="tekst">
                <h1>Velkommen til hovedprosjektet på Institutt for informasjonsteknologi</h1>
                Hovedprosjektene blir utført i siste semester i 3 klasse.<br/>
                Anskaffelse av oppgave og forberedelser til prosjektet skjer i løpet av høsten.
     </div>
     <?php

     ?>
    </body>
</html>


